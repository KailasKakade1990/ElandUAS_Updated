package com.eland.uas.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "resource")
public class Resource implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -308715090333576421L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "resource_id")
	private Long resourceId;
	@Column(name = "path",unique = true)
	private String path;
	@Column(name = "description")
	private String description;
	@Column(name = "is_use",columnDefinition = "BIGINT(20) default 1")
	private Long isUse;

	
	public Long getResourceId() {
		return resourceId;
	}

	public void setResourceId(Long resourceId) {
		this.resourceId = resourceId;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Long getIsUse() {
		return isUse;
	}

	public void setIsUse(Long isUse) {
		this.isUse = isUse;
	}

	/*
	 * @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy =
	 * "resource") private Set<SystemsResource> resourceDetails = new
	 * HashSet<SystemsResource>(0);
	 */

	/*
	 * public Set<SystemsResource> getResourceDetails() { return resourceDetails; }
	 * 
	 * public void setResourceDetails(Set<SystemsResource> resourceDetails) {
	 * this.resourceDetails = resourceDetails; }
	 */
}
