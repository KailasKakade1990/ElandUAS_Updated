package com.eland.uas.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "system")
public class Systems implements Serializable {

	private static final long serialVersionUID = -9016675688434755025L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "system_id")
	private Long systemId;
	@Column(name = "name",unique = true)
	private String name;
	@Column(name = "description")
	private String description;
	@Column(name = "in_use",columnDefinition = "BIGINT(20) default 1")
	private Long isUse;
	@Column(name = "in_otp_use")
	private Long inOtpUse;
	@Column(name = "client_id")
	private String clientId;
	@Column(name = "client_secret")
	private String clientSecret;
	@Column(name = "role_count",columnDefinition = "BIGINT(20) default 0")
	private Long roleCount;
	@Column(name = "user_count",columnDefinition = "BIGINT(20) default 0")
	private Long userCount;
	@Column(name = "resource_count",columnDefinition = "BIGINT(20) default 0")
	private Long resourceCount;

	public Long getIsUse() {
		return isUse;
	}

	public void setIsUse(Long isUse) {
		this.isUse = isUse;
	}

	public Long getSystemId() {
		return systemId;
	}

	public void setSystemId(Long systemId) {
		this.systemId = systemId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Long getInOtpUse() {
		return inOtpUse;
	}

	public void setInOtpUse(Long inOtpUse) {
		this.inOtpUse = inOtpUse;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getClientSecret() {
		return clientSecret;
	}

	public void setClientSecret(String clientSecret) {
		this.clientSecret = clientSecret;
	}

	public Long getRoleCount() {
		return roleCount;
	}

	public void setRoleCount(Long roleCount) {
		this.roleCount = roleCount;
	}

	public Long getUserCount() {
		return userCount;
	}

	public void setUserCount(Long userCount) {
		this.userCount = userCount;
	}

	public Long getResourceCount() {
		return resourceCount;
	}

	public void setResourceCount(Long resourceCount) {
		this.resourceCount = resourceCount;
	}

}