package com.eland.uas.passwordutil;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class PasswordUtil {

	static BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

	public static String getPasswordHash(String password) {
		// TODO Auto-generated method stub
		return encoder.encode(password);

	}

	public static boolean matchPassword(String rawPassword, String encodedPassword) {

		return encoder.matches(rawPassword, encodedPassword);
	}

}
