package com.eland.uas.controller;

import java.math.BigInteger;
import java.security.Principal;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.eland.uas.entity.AssignSystemResource;
import com.eland.uas.entity.Otp;
import com.eland.uas.entity.Resource;
import com.eland.uas.entity.Role;
import com.eland.uas.entity.SystemOtp;
import com.eland.uas.entity.Systems;
import com.eland.uas.entity.SystemsResource;
import com.eland.uas.entity.SystemsRole;
import com.eland.uas.entity.User;
import com.eland.uas.entity.UserSystemResource;
import com.eland.uas.entity.UserSystemsRole;
import com.eland.uas.passwordutil.PasswordUtil;
import com.eland.uas.repository.OtpRepository;
import com.eland.uas.repository.ResourceRepository;
import com.eland.uas.repository.RoleRepository;
import com.eland.uas.repository.SystemOtpRepository;
import com.eland.uas.repository.SystemsResourceRepository;
import com.eland.uas.repository.SystemsRespository;
import com.eland.uas.repository.SystemsRoleRepository;
import com.eland.uas.repository.UserRepository;
import com.eland.uas.repository.UserSystemsResourceRepository;
import com.eland.uas.repository.UserSystemsRoleRepository;
import com.eland.uas.reqresp.OtpValidateRequest;
import com.eland.uas.reqresp.SystemOtpRequest;
import com.eland.uas.reqrespmodel.CommonGetInfoResponse;
import com.eland.uas.reqrespmodel.CommonRequest;
import com.eland.uas.reqrespmodel.CommonResponse;
import com.eland.uas.reqrespmodel.GetInfoMinimulRequest;
import com.eland.uas.reqrespmodel.PasswordRequestResp;
import com.eland.uas.reqrespmodel.ResourceRequest;
import com.eland.uas.reqrespmodel.RoleRequest;
import com.eland.uas.reqrespmodel.SetUserSystemResource;
import com.eland.uas.reqrespmodel.SystemsRequest;
import com.eland.uas.reqrespmodel.UserRequest;
import com.eland.uas.reqrespmodel.UserRoleResponse;
import com.eland.uas.service.PreLoginUserService;

@RestController
@RequestMapping("/uas")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class AdminController {
	private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

	@Autowired
	private ResourceRepository resourceRepository;
	@Autowired
	private RoleRepository roleRepository;
	@Autowired
	private SystemsResourceRepository systemsResourceRepository;
	@Autowired
	private SystemsRespository systemsRepository;
	@Autowired
	private SystemsRoleRepository systemsRoleRepository;
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private UserSystemsRoleRepository userSystemsRoleRepository;
	@Autowired
	private UserSystemsResourceRepository userSystemsResourceRepository;
	@Autowired
	private PreLoginUserService userService;
	@Autowired
	private SystemOtpRepository systemOtpRepository;
	@Autowired
	private OtpRepository otpRepository;
	HttpHeaders respHeader = new HttpHeaders();
	/**********************************************************/
	// User API

	/*@PostMapping("/user")
	public String addUser(@RequestBody User user) {
		UserSystemsRole userSystemRole = null;
		String[] systemIds = user.getSystem_id();
		System.out.println("SysId:" + systemIds);
		String[] roleIds = user.getRole_id();
		User user1 = userRepository.save(user);
		System.out.println("User1:"+user1);
		
		for (String sysId : systemIds) {
			for (String roleId : roleIds) {
				userSystemRole = new UserSystemsRole();
				userSystemRole.setUser(user1);
				Systems system = systemsRepository.getOne(Long.parseLong(sysId));
				userSystemRole.setSystem(system);
				Role role = roleRepository.getOne(Long.parseLong(roleId));
				userSystemRole.setRole(role);
				userSystemsRoleRepository.save(userSystemRole);
			}
		}
		return "User Saved Successfully!";
	}

	// List all Users from database;
	@GetMapping("/user")
	public List<UserSystemsRole> getUserList() {
		logger.debug("Get All UserLists");
		//return userRepository.findAll();
		return userSystemsRoleRepository.findAll();
	}

	// Return one Users from database;
	@GetMapping("user/{userId}")
	public Optional<User> getById(@PathVariable Long userId) {

		return userRepository.findById(userId);
	}

	// delete Single user by id of the Users from database;
	@DeleteMapping("user/{userId}")
	public boolean deleteUser(@PathVariable Long userId) {
		userRepository.deleteById(userId);
		return true;
	}

	// Update user Single user by id of the Users from database;
	@PutMapping("user/{userId}")
	public User updateUser(User user) {

		return userRepository.save(user);
	}

	*//**********************************************************//*

	// System API

	@PostMapping("/system")
	public String addSystem(@RequestBody Systems systemResource) {

		// Role role = null;
		//Systems system = null;
		// Resource resource = null;
		//system = systemResource.getSystem();
		// resource = systemResource.getResource();

		systemsRepository.save(systemResource);

		return "System Saved Successfully!";
	}

	// List all Users from database;
	@GetMapping("/system")
	public List<Systems> getSytemList() {
		logger.debug("Get All system");
		System.out.println("Hitting ");
		return systemsRepository.findAll();
	}

	// Return one Users from database;
	@GetMapping("system/{systemId}")
	public Optional<Systems> getSystemById(@PathVariable Long systemId) {
		logger.info("System Saved Successfully" + systemId);
		return systemsRepository.findById(systemId);
	}

	// delete Single user by id of the Users from database;
	@DeleteMapping("system/{systemId}")
	public boolean deleteSystem(@PathVariable Long systemId) {
		logger.info("System Saved Successfully" + systemId);
		userRepository.deleteById(systemId);
		return true;
	}

	// Update system from database;
	@PutMapping("system/{systemId}")
	public Systems update(Systems system) {

		return systemsRepository.save(system);
	}

	*//**********************************************************//*
	// Resource API
	@PostMapping("/resource")
	public String addResource(@RequestBody Resource resource) {
		resourceRepository.save(resource);
		logger.info("Resource Saved Successfully");
		return "Resource Saved Successfully!";

	}

	// List all Users from database;
	@GetMapping("/resource")
	public List<Resource> getResourceList() {
		logger.debug("Get All resources");
		System.out.println("Resource List:"+ resourceRepository.findAll());
		return resourceRepository.findAll();
	}

	// Return one resource from database;
	@GetMapping("resource/{resourceId}")
	public Optional<Resource> getResourceById(@PathVariable Long resourceId) {
		logger.info("Get one Resource by id" + resourceId);
		return resourceRepository.findById(resourceId);
	}

	// delete Single resource by id of the Users from database;
	@DeleteMapping("resource/{resourceId}")
	public boolean deleterResource(@PathVariable Long resourecId) {
		logger.info("Resource deleted Successfully!" + resourecId);
		userRepository.deleteById(resourecId);
		return true;
	}

	// Update user Single user by id of the Users from database;
	@PutMapping("resource/{resourceId}")
	public Resource update(Resource resource) {
		logger.info("Resource Saved Successfully!" + resource);
		return resourceRepository.save(resource);
	}

	*//**********************************************************//*
	// Add Role API

	// Add Role
	@PostMapping("/role")
	public String addRole(@RequestBody Role role) {
		roleRepository.save(role);
		logger.info("Role Saved Successfully!" + role);
		return "Role Saved Successfully";
	}

	// List all Users from database;
	@GetMapping("/role")
	public List<Role> getRoleList() {
		logger.debug("Get All Roles" + roleRepository.findAll());
		return roleRepository.findAll();
	}
	
	@GetMapping("/getAssignedRole")
	public List<UserSystemsRole> getAssignedRoleList() {
		logger.debug("Get All Roles" + userSystemsRoleRepository.findAll());
		return userSystemsRoleRepository.findAll();
	}
	
	// getdata for Unassign/Assign Role to SystemResource
	@RequestMapping(value="/getRoleSystem", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> getRoleBySystemId(@RequestHeader HttpHeaders headers, @RequestBody Object obj ) {
		String tokenS = "token1234";
		System.out.println("Header Token:"+headers.get("accesstoken"));
		//return userSystemsRoleRepository.getRoleBySystemId(systemId);
		String token = headers.get("accessToken").toString();
		if(tokenS.equals(token)) {
			System.out.println("True");
		}
		
		
		return null;
	}
	
	// getdata for Unassign/Assign User to SystemResource
	@GetMapping("/getUserBySystemId/{systemId}")
	public List<User> getUserBySystemId(@PathVariable Long systemId) {
		return userSystemsRoleRepository.getUserBySystemId(systemId);
	}
	
	// getdata for Unassign/Assign SystemResource to Role
	@GetMapping("/getResourceBySystemId/{roleId}")
	public List<Resource> getResourceBySystemId(@PathVariable Long systemId) {
		return systemsResourceRepository.getResourceBySystemId(systemId);
	}

	// getd
	@GetMapping("/assignRoleSystemResource")
	public List<Resource> assignRoleSystemResource(@PathVariable Long systemId) {
		return systemsResourceRepository.getResourceBySystemId(systemId);
	}
	
	@GetMapping("/getAssignRoleSystemResource")
	public List<Role> getAssignRoleSystemResource(@PathVariable Long systemId) {
		return systemsResourceRepository.getResourceBySystemId(systemId);
	}
	
	// Return one role database by id;
	@GetMapping("role/{roleId}")
	public Optional<Role> roleFindById(@PathVariable Long roleId) {
		logger.debug("FindRoleBy ID Roles" + roleId);
		return roleRepository.findById(roleId);
	}

	// delete role from database
	@DeleteMapping("role/{roleId}")
	public boolean roleDeleteById(@PathVariable Long roleId) {
		userRepository.deleteById(roleId);
		logger.debug("Role Deleted Successfully!" + roleId);
		return true;
	}

	// Update by id
	@PutMapping("role/{roleId}")
	public Role update(Role role) {
		logger.debug("Role Updated Successfully!" + role);
		return roleRepository.save(role);
	}

	@PostMapping("/systemResources")
	public String addSystemResources(@RequestBody AssignSystemResource systemresource) {

		SystemsResource sysResource = new SystemsResource();
		String[] systemIds = systemresource.getSystemId();
		String[] resourceIds = systemresource.getResourceId();
		for (String sysId : systemIds) {
			for (String resourceId : resourceIds) {
				Systems system = systemsRepository.getOne(Long.parseLong(sysId));
				System.out.println("SID:"+system.getSystemId());
				sysResource.setSystem(system);
				Resource resource = resourceRepository.getOne(Long.parseLong(resourceId));
				System.out.println("RID:"+resource.getResourceId());
				sysResource.setResource(resource);
				sysResource.setIsUse(systemresource.getIsUse());
				systemsResourceRepository.save(sysResource);
			}
		}
		logger.info("Resources Assigned Successfully!" + sysResource);
		return "Role Saved Successfully";
	}
	@GetMapping("/systemResources")
	public List<SystemsResource> viewSystemResources() {
		System.out.println("System Resources:"+systemsResourceRepository.findAll());
		return systemsResourceRepository.findAll();
	}*/
	
	//@PostMapping("/changepassword/{id}")
	@RequestMapping(value="/changeUserPw", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<CommonResponse> updatePassword(@RequestBody PasswordRequestResp pwdReqResp, Principal principal) {
		CommonResponse response = new CommonResponse();
		if (principal != null) {
			User user = userRepository.findByUserId(pwdReqResp.getUserId());
			String password = PasswordUtil.getPasswordHash(pwdReqResp.getOldPassword());
			boolean successStatus = PasswordUtil.matchPassword(pwdReqResp.getOldPassword(), user.getPassword());
			if (successStatus) {
				user.setPassword(pwdReqResp.getNewPassword());
				userService.save(user);
				response.setSuccess(true);
				response.setMessage("Set Password Success");
				response.setCode("200");
				return  ResponseEntity.ok().headers(respHeader).body(response);
			} else {
				response.setSuccess(false);
				response.setMessage("Password does not match");
				response.setCode("9999");
				return  ResponseEntity.ok().headers(respHeader).body(response);
			}
		} else {
			response.setSuccess(false);
			response.setMessage("Un Authorized Request");
			response.setCode("9999");
			return  ResponseEntity.status(401).headers(respHeader).body(response);
		}
	}

	//@PostMapping("/resetpassword")
	@RequestMapping(value="/resetUserPw", method = RequestMethod.POST,
	consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> resetPassword(@RequestBody PasswordRequestResp pwdReqResp, Principal principal) {
		try {
			if (principal != null) {
				String htmlData = "localhost:8081/uas/setpassword/(userId)?newPassword=(Insert new password)";
				String subject = "Reset Your Password ElandUAS";
				return new ResponseEntity<>(userService.sendEmail(pwdReqResp.getEmail(), subject, htmlData), HttpStatus.OK);
			} else {
				return new ResponseEntity<>("Unauthorized Request", HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			return new ResponseEntity<>("Mail Not Sent", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/*//@PostMapping("/setpassword/{id}")
	@RequestMapping(value="/setpassword", method = RequestMethod.POST,
	consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> setNewPassword(@RequestBody PasswordRequestResp pwdReqResp,
			Principal principal) {
			if (principal != null) {
				User user = userRepository.findByUserId(pwdReqResp.getUserId());
				user.setPassword(pwdReqResp.getNewPassword());
				userService.save(user);
			return new ResponseEntity<>("Your Password has been reseted successfully!", HttpStatus.OK);
		} else {
			return new ResponseEntity<>("Unauthorized Request", HttpStatus.BAD_REQUEST);

		}
	}*/
	
	@RequestMapping(value="/putOtpCode", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> checkOtp(@RequestHeader HttpHeaders headers,@RequestBody OtpValidateRequest otpValidateRequest,
			Principal principal) {
		CommonResponse response = new CommonResponse();
		if (principal != null) {
			Otp otp1 = otpRepository.findByOtpAndUserUserId(otpValidateRequest.getOtp(), otpValidateRequest.getUserId());
			if (otp1 != null) {
				response.setSuccess(true);
				response.setMessage("OTP is Valid, Login Sucsess");
				response.setCode("200");
				//response.setAccessToken(headers.get("accessToken").get(1));
				//respHeader.add("accessToken", headers.get("accessToken").get(1));
				return  ResponseEntity.ok().headers(respHeader).body(response);
			} else {
				response.setSuccess(false);
				response.setMessage("OTP is not Valid, Login not Sucsess");
				response.setCode("9999");
				return  ResponseEntity.status(200).headers(respHeader).body(response);
			}

		} else {
			response.setSuccess(false);
			response.setMessage("UnAuthorized Request");
			response.setCode("9999");
			return  ResponseEntity.status(200).headers(respHeader).body(response);
		}

	}
	@RequestMapping(value="/addSystemOtp", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> addSystemOtp(@RequestHeader HttpHeaders headers,@RequestBody SystemOtpRequest systemOtp, Principal principal) {
		SystemOtp systemOtpEntity;
		SystemOtp sysOtpExist = null;
		CommonResponse response = new CommonResponse();
		if (principal != null) {
			String email = principal.getName();
			User user = userRepository.findByUserLogId(email);
			UserSystemsRole userSystemsRole = userSystemsRoleRepository.findByUserUserId(user.getUserId());
			//Role role = roleRepository.getOne(userSystemsRole.getRole().getRoleId());
			Systems systems = systemsRepository.getOne(userSystemsRole.getSystemRole().getSystem().getSystemId());
			if (systems != null) {
				systemOtpEntity = new SystemOtp();
				String[] systemIds = systemOtp.getSystemId();
				for(String systemId:systemIds) {
				Systems systemsObj = systemsRepository.getOne(Long.parseLong(systemId));
				systemOtpEntity.setSystems(systemsObj);
				systemOtpEntity.setIpaddress(systemOtp.getIpAddress());
				systemOtpEntity.setDescription(systemOtp.getDescription());
				sysOtpExist = systemOtpRepository.save(systemOtpEntity);
				}
				response.setSuccess(true);
				response.setMessage("System OTP Saved Successfully");
				response.setCode("200");
				response.setAccessToken(headers.get("accessToken").get(0));
				respHeader.add("accessToken", headers.get("accessToken").get(0));
				return  ResponseEntity.ok().headers(respHeader).body(response);
			} else {
				response.setSuccess(false);
				response.setMessage("Access Denied");
				response.setCode("200");
				response.setAccessToken(headers.get("accessToken").get(0));
				respHeader.add("accessToken", headers.get("accessToken").get(0));
				return  ResponseEntity.status(401).headers(respHeader).body(response);
			}
		} else
		{
			response.setSuccess(false);
			response.setMessage("Unauthorized Request");
			response.setCode("200");
			response.setAccessToken(headers.get("accessToken").get(0));
			respHeader.add("accessToken", headers.get("accessToken").get(0));
			return  ResponseEntity.status(401).headers(respHeader).body(response);
		}
	}
	
	@RequestMapping(value="/setRoleInfo", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<CommonResponse> setRoleInfo(@RequestHeader HttpHeaders headers, @RequestBody RoleRequest roleRequest,Principal principal) {
		
		CommonResponse response = new CommonResponse();
		String systemRoleId = roleRequest.getSystemRoleId();
		boolean isUseBool = roleRequest.isUseYn();
		if(systemRoleId!=null) {
			SystemsRole existSystemRole = null;
			List<Role> existRoleEntity = roleRepository.getSystemRoleByNameNo(roleRequest.getWorkGrpNo(), roleRequest.getWorkGrpName());
			System.out.println("Role List:"+existRoleEntity.size());
			if(existRoleEntity.size()>0) {
				//get System info
				existSystemRole = systemsRoleRepository.getOne(Long.parseLong(systemRoleId));
				Systems systemEntity = systemsRepository.getOne(Long.parseLong(roleRequest.getSystemId()));
				existSystemRole.setSystem(systemEntity);
				existSystemRole.setRole(existRoleEntity.get(0));
				if(isUseBool) {
					existSystemRole.setIs_use(1L);
				} else {
					existSystemRole.setIs_use(0L);
				}
				existSystemRole.setDescription(roleRequest.getDescription());
				//save SystemRole entity
				SystemsRole systemRoleEntity = systemsRoleRepository.save(existSystemRole);		
				if(systemRoleEntity!=null) {				
					response.setSuccess(true);
					response.setMessage("Set Role success");
					response.setCode("200");
					response.setAccessToken(headers.get("accessToken").get(0));
					respHeader.add("accessToken", headers.get("accessToken").get(0));
					return  ResponseEntity.ok().headers(respHeader).body(response);
				} else {
					response.setSuccess(false);
					response.setMessage("Set Role not success");
					response.setCode("99");
					return  ResponseEntity.status(500).header("accessToken", headers.get("accessToken").get(0)).body(response);
				}				
			} else {
				
				
				Role role = new Role();
				role.setName(roleRequest.getWorkGrpName());
				role.setNumber(roleRequest.getWorkGrpNo());
				
				if(isUseBool) {
					role.setIsUse(1L);
				} else {
					role.setIsUse(0L);
				}
				//save Role entity
				Role roleEntity = roleRepository.save(role);
				if(roleEntity!=null) {
					//get System info
					existSystemRole = systemsRoleRepository.getOne(Long.parseLong(systemRoleId));
					Systems systemEntity = systemsRepository.getOne(Long.parseLong(roleRequest.getSystemId()));
					existSystemRole.setSystem(systemEntity);
					existSystemRole.setRole(roleEntity);
					if(isUseBool) {
						existSystemRole.setIs_use(1L);
					} else {
						existSystemRole.setIs_use(0L);
					}
					existSystemRole.setDescription(roleRequest.getDescription());
					//save SystemRole entity
					SystemsRole systemRoleEntity = systemsRoleRepository.save(existSystemRole);		
					
					if(systemRoleEntity!=null) {
						
						response.setSuccess(true);
						response.setMessage("Set Role success");
						response.setCode("200");
						response.setAccessToken(headers.get("accessToken").get(0));
						respHeader.add("accessToken", headers.get("accessToken").get(0));
						return  ResponseEntity.ok().headers(respHeader).body(response);
					} else {
						response.setSuccess(false);
						response.setMessage("Set Role not success");
						response.setCode("99");
						return  ResponseEntity.status(500).header("accessToken", headers.get("accessToken").get(0)).body(response);
					}
				} else {
					response.setSuccess(false);
					response.setMessage("Set Role not success");
					response.setCode("99");
					return  ResponseEntity.status(500).header("accessToken", headers.get("accessToken").get(0)).body(response);
				}
			}
		} else {
				// SET ROLE to SYSTEMS
			List<Long> systemRoleIdExist;
			List<BigInteger>  roleIdsExists =roleRepository.getRoleByNo(roleRequest.getWorkGrpNo());
			for(BigInteger roleId: roleIdsExists) {
				systemRoleIdExist = systemsRoleRepository.getEntityBySystemIdWrkGroup(Long.parseLong(roleRequest.getSystemId()),roleId.longValue());
				if(systemRoleIdExist.size()>0) {
						response.setSuccess(false);
						response.setMessage("WorkGrpNo is already Assigned to this System");
						response.setCode("99");
						return  ResponseEntity.status(500).header("accessToken", headers.get("accessToken").get(0)).body(response);
				}
			}
			SystemsRole systemRole = new SystemsRole();
			List<Role> existRoleEntity = roleRepository.getSystemRoleByNameNo(roleRequest.getWorkGrpNo(), roleRequest.getWorkGrpName());
			System.out.println("Role List:"+existRoleEntity.size());
			if(existRoleEntity.size()>0) {
				//get System info
				// check wheather system & role id available or not
				systemRoleIdExist = systemsRoleRepository.getEntityBySystemIdWrkGroup(Long.parseLong(roleRequest.getSystemId()),existRoleEntity.get(0).getRoleId());
				if(systemRoleIdExist.size()>0) {
					response.setSuccess(false);
					response.setMessage("WorkGrpNo is already Assigned to this System");
					response.setCode("99");
					return  ResponseEntity.status(500).header("accessToken", headers.get("accessToken").get(0)).body(response);
				}
				
				Systems systemEntity = systemsRepository.getOne(Long.parseLong(roleRequest.getSystemId()));
				systemRole.setSystem(systemEntity);
				systemRole.setRole(existRoleEntity.get(0));
				if(isUseBool) {
					systemRole.setIs_use(1L);
				} else {
					systemRole.setIs_use(0L);
				}
				systemRole.setDescription(roleRequest.getDescription());
				//save SystemRole entity
				SystemsRole systemRoleEntity = systemsRoleRepository.save(systemRole);
				//Update role count in system table
				
				if(systemRoleEntity!=null) {				
					response.setSuccess(true);
					response.setMessage("Set Role success");
					response.setCode("200");
					response.setAccessToken(headers.get("accessToken").get(0));
					respHeader.add("accessToken", headers.get("accessToken").get(0));
					return  ResponseEntity.ok().headers(respHeader).body(response);
				} else {
					response.setSuccess(false);
					response.setMessage("Set Role not success");
					response.setCode("99");
					return  ResponseEntity.status(500).header("accessToken", headers.get("accessToken").get(0)).body(response);
				}				
			} else {
				Role role = new Role();
				role.setName(roleRequest.getWorkGrpName());
				role.setNumber(roleRequest.getWorkGrpNo());
				
				if(isUseBool) {
					role.setIsUse(1L);
				} else {
					role.setIsUse(0L);
				}
				//save Role entity
				Role roleEntity = roleRepository.save(role);
				if(roleEntity!=null) {
					//get System info
					Systems systemEntity = systemsRepository.getOne(Long.parseLong(roleRequest.getSystemId()));
					systemRole.setSystem(systemEntity);
					systemRole.setRole(roleEntity);
					systemRole.setDescription(roleRequest.getDescription());
					if(isUseBool) {
						systemRole.setIs_use(1L);
					} else {
						systemRole.setIs_use(0L);
					}
					//save SystemRole entity
					SystemsRole systemRoleEntity = systemsRoleRepository.save(systemRole);
					
					if(systemRoleEntity!=null) {
						
						response.setSuccess(true);
						response.setMessage("Set Role success");
						response.setCode("200");
						response.setAccessToken(headers.get("accessToken").get(0));
						respHeader.add("accessToken", headers.get("accessToken").get(0));
						return  ResponseEntity.ok().headers(respHeader).body(response);
					} else {
						response.setSuccess(false);
						response.setMessage("Set Role not success");
						response.setCode("99");
						return  ResponseEntity.status(500).header("accessToken", headers.get("accessToken").get(0)).body(response);
					}
				} else {
					response.setSuccess(false);
					response.setMessage("Set Role not success");
					response.setCode("99");
					return  ResponseEntity.status(500).header("accessToken", headers.get("accessToken").get(0)).body(response);
				}
			}
		}
	} //// End of SetRoleInfo Api
	
	@RequestMapping(value="/addUserInfo", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<CommonResponse> addUser(@RequestHeader HttpHeaders headers, @RequestBody UserRequest userRequest) {
		
		//Check AccessToken &&  client validation
		
		Date applyStartDate, applyEndDate;
		UserSystemsRole userSystemRole = null;
		String[] systemRoleIds = userRequest.getSystemRole();
		User user = new User();
		user.setAccountNo(userRequest.getAccountNo());
		try {
		    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS");
		    if(userRequest.getApplyStartDate()!=null || userRequest.getApplyStartDate()!="") {
		    	applyStartDate = (Date) dateFormat.parse(userRequest.getApplyStartDate());
		    	user.setApplyStartDate(applyStartDate);
		    }
		    if(userRequest.getApplyEndDate()!=null || userRequest.getApplyEndDate()!="") {
		    	applyEndDate = (Date) dateFormat.parse(userRequest.getApplyEndDate());
		    	user.setApplyEndDate(applyEndDate);
		    }
		} catch(Exception e) {
		     System.out.println("Date Format Exception:"+e.getMessage());
		}
		
		if(userRequest.getEmailAddress()!=null || userRequest.getEmailAddress()!="") {
			user.setEmail(userRequest.getEmailAddress());
		}
		boolean isUseBool = userRequest.isUseYn();
		if(isUseBool) {
			user.setIsUse(1L);
		} else {
			user.setIsUse(0L);
		}
		user.setMobile(Long.parseLong(userRequest.getMobileNo()));
		user.setTelephone_No(Long.parseLong(userRequest.getTelNo()));
		user.setUserLogId(userRequest.getUserId());
		user.setUserName(userRequest.getUserNm());
		user.setPassword(userRequest.getUserPw());
		user.setEnabled(userRequest.isEnabled());
		userService.save(user);
		User user1 = userRepository.save(user);
		System.out.println("User1:"+user1);
		SystemsRole systemRoleEntity = null;  
		UserSystemsRole usrStatus = null;
		for (String systemRoleId : systemRoleIds) {
			userSystemRole = new UserSystemsRole();
			userSystemRole.setUser(user1);
			systemRoleEntity = new SystemsRole();
			systemRoleEntity = systemsRoleRepository.getOne(Long.parseLong(systemRoleId));
			userSystemRole.setSystemRole(systemRoleEntity);
			if(isUseBool) {
				userSystemRole.setIsUse(1L);
			} else {
				userSystemRole.setIsUse(0L);
			}
			usrStatus = userSystemsRoleRepository.save(userSystemRole);
		}
		CommonResponse response = new CommonResponse();
		if(usrStatus!=null) {
			response.setSuccess(true);
			response.setMessage("User Added Successfully");
			response.setCode("200");
			response.setAccessToken(headers.get("accessToken").get(0));
			return  ResponseEntity.ok().headers(respHeader).body(response);
		} else {
			response.setSuccess(false);
			response.setMessage("User Not added");
			response.setCode("99");
			return  ResponseEntity.status(500).header("accessToken", headers.get("accessToken").get(0)).body(response);
		}
	} // // End of addUserInfo Api
	
	@RequestMapping(value="/changeUserInfo", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<CommonResponse> editUser(@RequestHeader HttpHeaders headers, @RequestBody UserRequest userRequest,Principal principal) {
		
		//Check AccessToken &&  client validation
		
		Date applyStartDate, applyEndDate;
		UserSystemsRole userSystemRole = null;
		String[] systemRoleIds = userRequest.getSystemRole();
		User user = userRepository.getOne(userRequest.getId());
		user.setAccountNo(userRequest.getAccountNo());
		try {
		    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS");
		    if(userRequest.getApplyStartDate()!=null || userRequest.getApplyStartDate()!="") {
		    	applyStartDate = (Date) dateFormat.parse(userRequest.getApplyStartDate());
		    	user.setApplyStartDate(applyStartDate);
		    }
		    if(userRequest.getApplyEndDate()!=null || userRequest.getApplyEndDate()!="") {
		    	applyEndDate = (Date) dateFormat.parse(userRequest.getApplyEndDate());
		    	user.setApplyEndDate(applyEndDate);
		    }
		} catch(Exception e) {
		     System.out.println("Date Format Exception:"+e.getMessage());
		}
		
		if(userRequest.getEmailAddress()!=null || userRequest.getEmailAddress()!="") {
			user.setEmail(userRequest.getEmailAddress());
		}
		boolean isUseBool = userRequest.isUseYn();
		if(isUseBool) {
			user.setIsUse(1L);
		} else {
			user.setIsUse(0L);
		}
		user.setMobile(Long.parseLong(userRequest.getMobileNo()));
		user.setTelephone_No(Long.parseLong(userRequest.getTelNo()));
		user.setUserLogId(userRequest.getUserId());
		user.setUserName(userRequest.getUserNm());
		user.setPassword(userRequest.getUserPw());
		
		User user1 = userRepository.save(user);
		System.out.println("User1:"+user1);
		SystemsRole systemRoleEntity = null;  
		UserSystemsRole usrStatus = null;
		/*for (String systemRoleId : systemRoleIds) {
			boolean isSystemRoleExist = userSystemsRoleRepository.existsById(Long.parseLong(systemRoleId));
			//List<Long> existsystemIds = userSystemsRoleRepository.getSystemIdByUserId(user1.getUserId());
			if(isSystemRoleExist) {
			} else {
				userSystemRole = new UserSystemsRole();
				systemRoleEntity = new SystemsRole();
				systemRoleEntity = systemsRoleRepository.getOne(Long.parseLong(systemRoleId));
				userSystemRole.setSystemRole(systemRoleEntity);
				if(isUseBool) {
					userSystemRole.setIsUse(1);
				} else {
					userSystemRole.setIsUse(0);
				}
				usrStatus = userSystemsRoleRepository.save(userSystemRole);
			}
		}*/
		CommonResponse response = new CommonResponse();
		if(user1!=null) {
			response.setSuccess(true);
			response.setMessage("User Added Successfully");
			response.setCode("200");
			response.setAccessToken(headers.get("accessToken").get(0));
			respHeader.add("accessToken", headers.get("accessToken").get(0));
			return  ResponseEntity.ok().headers(respHeader).body(response);
		} else {
			response.setSuccess(false);
			response.setMessage("User Not added");
			response.setCode("99");
			return  ResponseEntity.status(500).header("accessToken", headers.get("accessToken").get(0)).body(response);
		}
	} // End of changeUserInfo Api
	
	//Set Resource Info
	@RequestMapping(value="/setResourceInfo", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<CommonResponse> setResourceInfo(Principal principal,@RequestHeader HttpHeaders headers, @RequestBody ResourceRequest resourceRequest) {
		
		CommonResponse response = new CommonResponse();
		String systemRoleId = resourceRequest.getSystemResourceId();
		boolean isUseBool = resourceRequest.isUseYn();
		if(systemRoleId!=null) {
			SystemsResource existSystemResource = null;
			List<Resource> existResourceEntity = resourceRepository.getResourceByPath(resourceRequest.getResourcePath());
			System.out.println("Resource List:"+existResourceEntity.size());
			if(existResourceEntity.size()>0) {
				//get System info
				existSystemResource = systemsResourceRepository.getOne(Long.parseLong(systemRoleId));
				Systems systemEntity = systemsRepository.getOne(Long.parseLong(resourceRequest.getSystemId()));
				existSystemResource.setSystem(systemEntity);
				existResourceEntity.get(0).setPath(resourceRequest.getResourcePath());
				existResourceEntity.get(0).setDescription(resourceRequest.getResourceDesc());
				if(isUseBool) {
					existResourceEntity.get(0).setIsUse(1L);
				} else {
					existResourceEntity.get(0).setIsUse(0L);
				}
				existSystemResource.setResource(existResourceEntity.get(0));
				if(isUseBool) {
					existSystemResource.setIsUse(1L);
				} else {
					existSystemResource.setIsUse(0L);
				}
				//save SystemRole entity
				SystemsResource systemResourceEntity = systemsResourceRepository.save(existSystemResource);		
				if(systemResourceEntity!=null) {				
					response.setSuccess(true);
					response.setMessage("Set Role success");
					response.setCode("200");
					response.setAccessToken(headers.get("accessToken").get(0));
					respHeader.add("accessToken", headers.get("accessToken").get(0));
					return  ResponseEntity.ok().headers(respHeader).body(response);
				} else {
					response.setSuccess(false);
					response.setMessage("Set Resource not success");
					response.setCode("99");
					return  ResponseEntity.status(500).header("accessToken", headers.get("accessToken").get(0)).body(response);
				}				
			} else {
				Resource resource = new Resource();
				resource.setPath(resourceRequest.getResourcePath());
				resource.setDescription(resourceRequest.getResourceDesc());
				
				if(isUseBool) {
					resource.setIsUse(1L);
				} else {
					resource.setIsUse(0L);
				}
				//save Role entity
				Resource resourceEntity = resourceRepository.save(resource);
				if(resourceEntity!=null) {
					//get System info
					existSystemResource = systemsResourceRepository.getOne(Long.parseLong(systemRoleId));
					Systems systemEntity = systemsRepository.getOne(Long.parseLong(resourceRequest.getSystemId()));
					existSystemResource.setSystem(systemEntity);
					existSystemResource.setResource(resourceEntity);
					if(isUseBool) {
						existSystemResource.setIsUse(1L);
					} else {
						existSystemResource.setIsUse(0L);
					}
					//save SystemRole entity
					SystemsResource systemResourceEntity = systemsResourceRepository.save(existSystemResource);		
					
					if(systemResourceEntity!=null) {
						
						response.setSuccess(true);
						response.setMessage("Set Resource success");
						response.setCode("200");
						response.setAccessToken(headers.get("accessToken").get(0));
						respHeader.add("accessToken", headers.get("accessToken").get(0));
						return  ResponseEntity.ok().headers(respHeader).body(response);
					} else {
						response.setSuccess(false);
						response.setMessage("Set Resource not success");
						response.setCode("99");
						return  ResponseEntity.status(500).header("accessToken", headers.get("accessToken").get(0)).body(response);
					}
				} else {
					response.setSuccess(false);
					response.setMessage("Set Resource not success");
					response.setCode("99");
					return  ResponseEntity.status(500).header("accessToken", headers.get("accessToken").get(0)).body(response);
				}
			}
		} else {
			SystemsResource systemResource = new SystemsResource();
			//yet to start
			List<Resource> existResourceEntity = resourceRepository.getResourceByPath(resourceRequest.getResourcePath());
			System.out.println("Resource List:"+existResourceEntity.size());
			if(existResourceEntity.size()>0) {
				//get System info
				Systems systemEntity = systemsRepository.getOne(Long.parseLong(resourceRequest.getSystemId()));
				systemResource.setSystem(systemEntity);
				existResourceEntity.get(0).setDescription(resourceRequest.getResourceDesc());
				systemResource.setResource(existResourceEntity.get(0));
				if(isUseBool) {
					systemResource.setIsUse(1L);
				} else {
					systemResource.setIsUse(0L);
				}
				//save SystemRole entity
				SystemsResource systemResourceEntity = systemsResourceRepository.save(systemResource);
				if(systemResourceEntity!=null) {				
					response.setSuccess(true);
					response.setMessage("Set Resource success");
					response.setCode("200");
					response.setAccessToken(headers.get("accessToken").get(0));
					respHeader.add("accessToken", headers.get("accessToken").get(0));
					respHeader.add("clientId", headers.get("accessToken").get(0));
					respHeader.add("clientSecret", headers.get("accessToken").get(0));
					return  ResponseEntity.ok().headers(respHeader).body(response);
				} else {
					response.setSuccess(false);
					response.setMessage("Set Resource not success");
					response.setCode("99");
					return  ResponseEntity.status(500).header("accessToken", headers.get("accessToken").get(0)).body(response);
				}
			} else {
				Resource resource = new Resource();
				resource.setPath(resourceRequest.getResourcePath());
				resource.setDescription(resourceRequest.getResourceDesc());
				
				if(isUseBool) {
					resource.setIsUse(1L);
				} else {
					resource.setIsUse(0L);
				}
				//save Role entity
				Resource resourceEntity = resourceRepository.save(resource);
				if(resourceEntity!=null) {
					//get System info
					Systems systemEntity = systemsRepository.getOne(Long.parseLong(resourceRequest.getSystemId()));
					systemResource.setSystem(systemEntity);
					systemResource.setResource(resourceEntity);
					if(isUseBool) {
						systemResource.setIsUse(1L);
					} else {
						systemResource.setIsUse(0L);
					}
					//save SystemRole entity
					SystemsResource systemResourceEntity = systemsResourceRepository.save(systemResource);
					
					if(systemResourceEntity!=null) {
						
						response.setSuccess(true);
						response.setMessage("Set Resource success");
						response.setCode("200");
						response.setAccessToken(headers.get("accessToken").get(0));
						respHeader.add("accessToken", headers.get("accessToken").get(0));
						respHeader.add("clientId", headers.get("accessToken").get(0));
						respHeader.add("clientSecret", headers.get("accessToken").get(0));
						return  ResponseEntity.ok().headers(respHeader).body(response);
					} else {
						response.setSuccess(false);
						response.setMessage("Set Resource not success");
						response.setCode("99");
						return  ResponseEntity.status(500).header("accessToken", headers.get("accessToken").get(0)).body(response);
					}
				} else {
					response.setSuccess(false);
					response.setMessage("Set Resource not success");
					response.setCode("99");
					return  ResponseEntity.status(500).header("accessToken", headers.get("accessToken").get(0)).body(response);
				}
			}
		}
	} // End of SetResourceInfo Api
	
	@RequestMapping(value="/getUserInfo", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> getAllUserInfo(Principal principal,@RequestHeader HttpHeaders headers) {
		CommonGetInfoResponse response = new CommonGetInfoResponse();
		if (principal != null) {
		String userId = principal.getName();
		User user = userRepository.findByUserLogId(userId);
		List<BigInteger> systemIds = userSystemsRoleRepository.getSystemIdByUserId(user.getUserId());
		Systems systemExist = null;
		for(BigInteger systemId:systemIds) {
			systemExist = systemsRepository.getOne(systemId.longValue());
		}
		if(systemExist==null) {
			response.setSuccess(false);
			response.setMessage("Access Denied");
			response.setCode("99");
			respHeader.add("accessToken",headers.get("accessToken").get(0));
			return  ResponseEntity.status(401).header("accessToken", headers.get("accessToken").get(0)).body(response);
		}
		List<UserSystemsRole> usrList = new ArrayList<>();
		usrList = userSystemsRoleRepository.findAll();
		response.setDetails(usrList);
		response.setSuccess(true);
		if(usrList.size()>0) {
			response.setMessage("User Information success");
		} else {
			response.setMessage("No User information Available");
		}
		response.setCode("200");
		//response.setAccessToken(headers.get("accessToken").get(0));
		//respHeader.add("accessToken", headers.get("accessToken").get(0));
		/*respHeader.add("clientId", headers.get("accessToken").get(0));
		respHeader.add("clientSecret", headers.get("accessToken").get(0));*/
		return  ResponseEntity.ok().body(response);
		}else {
			response.setSuccess(false);
			response.setMessage("Unauthorized Request");
			response.setCode("99");
			respHeader.add("accessToken",headers.get("accessToken").get(0));
			return  ResponseEntity.status(400).header("accessToken", headers.get("accessToken").get(0)).body(response);
		}
	}
	
	@RequestMapping(value="/getAllSystem", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> getAllSystem(@RequestHeader HttpHeaders headers) {
		List<Systems> systemList = new ArrayList<>();
		systemList = systemsRepository.findAll();
		CommonGetInfoResponse response = new CommonGetInfoResponse();
		response.setDetails(systemList);
		response.setSuccess(true);
		if(systemList.size()>0) {
			response.setMessage("System  Information success");
		} else {
			response.setMessage("No Role information Available");
		}
		response.setCode("200");
		response.setAccessToken(headers.get("accessToken").get(0));
		respHeader.add("accessToken", headers.get("accessToken").get(0));
		return  ResponseEntity.ok().headers(respHeader).body(response);
	}
	
	@RequestMapping(value="/getAllSystemRole", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> getAllSystemRole(Principal principal,@RequestHeader HttpHeaders headers) {
		System.out.println("Hi");
		List<SystemsRole> systemRoleList = new ArrayList<>();
		systemRoleList = systemsRoleRepository.findAll();
		CommonGetInfoResponse response = new CommonGetInfoResponse();
		response.setDetails(systemRoleList);
		response.setSuccess(true);
		if(systemRoleList.size()>0) {
			response.setMessage("System Role Information success");
		} else {
			response.setMessage("No Role information Available");
		}
		response.setCode("200");
		response.setAccessToken(headers.get("accessToken").get(0));
		respHeader.add("accessToken", headers.get("accessToken").get(0));
		return  ResponseEntity.ok().headers(respHeader).body(response);
	}
	
	@RequestMapping(value="/getAllResource", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<CommonGetInfoResponse> getAllResource(@RequestHeader HttpHeaders headers) {
		List<SystemsResource> systemsResourceList = new ArrayList<>();
		systemsResourceList = systemsResourceRepository.findAll();
		CommonGetInfoResponse response = new CommonGetInfoResponse();
		response.setDetails(systemsResourceList);
		response.setSuccess(true);
		if(systemsResourceList.size()>0) {
			response.setMessage("System Resource Information success");
		} else {
			response.setMessage("No Resource information Available");
		}
		response.setCode("200");
		response.setAccessToken(headers.get("accessToken").get(0));
		respHeader.add("accessToken", headers.get("accessToken").get(0));
		return  ResponseEntity.ok().headers(respHeader).body(response);
	}
	
	@RequestMapping(value="/getUserRole", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<CommonGetInfoResponse> getUserRole(Principal principal,@RequestHeader HttpHeaders headers, @RequestBody GetInfoMinimulRequest getInfoRequest) {
		String systemRoleId = getInfoRequest.getId();
		List<User> userSystemRoleList = userSystemsRoleRepository.getUserBySystemRoleId(Long.parseLong(systemRoleId));
		CommonGetInfoResponse response = new CommonGetInfoResponse();
		response.setDetails(userSystemRoleList);
		response.setSuccess(true);
		if(userSystemRoleList.size()>0) {
			response.setMessage("System Role Information success");
		} else {
			response.setMessage("No User Role information Available");
		}
		response.setCode("200");
		response.setAccessToken(headers.get("accessToken").get(0));
		respHeader.add("accessToken", headers.get("accessToken").get(0));
		return  ResponseEntity.ok().headers(respHeader).body(response);
	}
	
		// Assign system Resource to user who belongs
	@RequestMapping(value="/setUserResource", method = RequestMethod.POST,
	consumes = "application/json", produces = "application/json")
	public ResponseEntity<CommonGetInfoResponse> assignResourceToUser(Principal principal,@RequestHeader HttpHeaders headers, @RequestBody SetUserSystemResource userSystemResource) {
		String userSystemRoleId = userSystemResource.getUserSystemRoleId();
		String[] systemResourceIds = userSystemResource.getSystemResourceId();
		UserSystemsRole userSystemRoleEntity = userSystemsRoleRepository.getOne(Long.parseLong(userSystemRoleId));
		UserSystemResource usrStatus = null;
		for(String systemResourceId: systemResourceIds) {
			UserSystemResource userSystemResourceEntity = new UserSystemResource();
			SystemsResource systemResourceEntity = systemsResourceRepository.getOne(Long.parseLong(systemResourceId));
			userSystemResourceEntity.setUsersystemRole(userSystemRoleEntity);
			userSystemResourceEntity.setSystemResource(systemResourceEntity);
			usrStatus = userSystemsResourceRepository.save(userSystemResourceEntity);
		}
		CommonGetInfoResponse response = new CommonGetInfoResponse();
		response.setSuccess(true);
		if(usrStatus!=null) {
			response.setMessage("Set UserResource success");
			response.setCode("200");
			response.setAccessToken(headers.get("accessToken").get(0));
			respHeader.add("accessToken", headers.get("accessToken").get(0));
			return  ResponseEntity.ok().headers(respHeader).body(response);
		} else {
			response.setSuccess(false);
			response.setMessage("Add Role not success");
			response.setCode("99");
			return  ResponseEntity.ok().headers(respHeader).body(response);
		}
	}
	
	
	
					// Get Resource which is assigned to user
	@RequestMapping(value="/getUserResource", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<CommonGetInfoResponse> getUserResource(Principal principal,@RequestHeader HttpHeaders headers, @RequestBody GetInfoMinimulRequest getInfoRequest) {
		String userSystemRoleId = getInfoRequest.getId();
		List<Resource> resourceList = userSystemsResourceRepository.getResourceByUserId(userSystemRoleId);
		CommonGetInfoResponse response = new CommonGetInfoResponse();
		response.setDetails(resourceList);
		response.setSuccess(true);
		if(resourceList.size()>0) {
			response.setSuccess(true);
			response.setMessage("User Resource Available");
			response.setCode("200");
			response.setAccessToken(headers.get("accessToken").get(0));
			respHeader.add("accessToken", headers.get("accessToken").get(0));
			return  ResponseEntity.ok().headers(respHeader).body(response);
		} else {
			response.setSuccess(true);
			response.setMessage("User Resource Not Available");
			response.setCode("200");
			response.setAccessToken(headers.get("accessToken").get(0));
			respHeader.add("accessToken", headers.get("accessToken").get(0));
			return  ResponseEntity.ok().headers(respHeader).body(response);
		}
	}
	
	@RequestMapping(value="/getUserSystem", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<CommonGetInfoResponse> getUserSystem(Principal principal,@RequestHeader HttpHeaders headers, @RequestBody GetInfoMinimulRequest getInfoRequest) {
		String systemId = getInfoRequest.getId();
		
		// get SystemRoleId using systemId
		List<BigInteger> systemRoleIds = systemsRoleRepository.getSystemRoleIdbySystemId(Long.parseLong(systemId));
		System.out.println("systemRoleId list:"+systemRoleIds);
		Long[] systemRoleIdsLong = new Long[systemRoleIds.size()];
		int i=0;
		for(BigInteger sysRoleId: systemRoleIds) {
			systemRoleIdsLong[i] = sysRoleId.longValue();
			i++;
		}
		List<User> userSystemRoleList = userSystemsRoleRepository.getUserBySystemId(systemRoleIdsLong);
		CommonGetInfoResponse response = new CommonGetInfoResponse();
		response.setDetails(userSystemRoleList);
		response.setSuccess(true);
		if(userSystemRoleList.size()>0) {
			response.setMessage("System Role Information success");
		} else {
			response.setMessage("No User Role information Available");
		}
		response.setCode("200");
		response.setAccessToken(headers.get("accessToken").get(0));
		respHeader.add("accessToken", headers.get("accessToken").get(0));
		return  ResponseEntity.ok().headers(respHeader).body(response);
	}
	
	@RequestMapping(value="/addSystem", method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE,
			consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> addSystem(Principal principal,@RequestHeader HttpHeaders headers,@RequestBody SystemsRequest systemRequest) {
		
		System.out.println("Add system api invoked");
		Systems system = new Systems();
		system.setName(systemRequest.getName());
		system.setDescription(systemRequest.getDescription());
		system.setClientId(systemRequest.getClientId());
		system.setClientSecret(systemRequest.getClientSecret());
		system.setInOtpUse(systemRequest.getInOtpUse());
		system.setIsUse(systemRequest.getIsUse());
		
		Systems systemEntity = systemsRepository.save(system);
		CommonResponse response = new CommonResponse();
		if(systemEntity!=null) {
			response.setSuccess(true);
			response.setMessage("Add System success");
			response.setCode("200");
			response.setAccessToken(headers.get("accessToken").get(0));
			respHeader.add("accessToken", headers.get("accessToken").get(0));
			return  ResponseEntity.ok().headers(respHeader).body(response);
		} else {
			response.setSuccess(false);
			response.setMessage("Add System not success");
			response.setCode("99");
			return  ResponseEntity.ok().headers(respHeader).body(response);
		}
	}
	
	@RequestMapping(value="/addRole", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<CommonResponse> addRole(Principal principal,@RequestHeader HttpHeaders headers, @RequestBody Role role) {
		CommonResponse response = new CommonResponse();
		List<Role> roleExist = roleRepository.findRoleByNameNo(role.getName(),role.getNumber());
		if(roleExist.size()>0) {
			response.setSuccess(false);
			response.setMessage("Role Name and Number already exist");
			response.setCode("99");
			return  ResponseEntity.ok().headers(respHeader).body(response);
		}
		Role roleEntity = roleRepository.save(role);
		if(roleEntity!=null) {
			response.setMessage("Add Role success");
			response.setSuccess(true);
			response.setCode("200");
			response.setAccessToken(headers.get("accessToken").get(0));
			//respHeader.add("accessToken", headers.get("accessToken").get(0));
			//respHeader.add("clientId", headers.get("clientid").get(1));
			//respHeader.add("clientSecret", headers.get("secret").get(2));
			return  ResponseEntity.ok().headers(respHeader).body(response);
		} else {
			response.setSuccess(false);
			response.setMessage("Add Role not success");
			response.setCode("99");
			return  ResponseEntity.ok().headers(respHeader).body(response);
		}
	}
}
