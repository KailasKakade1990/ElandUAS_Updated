package com.eland.uas.repository;

import java.math.BigInteger;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.eland.uas.entity.Role;

@Repository
@Transactional(readOnly = true)
public class CustomRoleRepositoryImpl implements CustomRoleRepository {

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public List<Role> getSystemRoleByNameNo(Long wrkGrpNo, String wrkGrpName) {
		Query query = entityManager.createNativeQuery("select * from role where number="+wrkGrpNo+" and name='"+wrkGrpName+"' ", Role.class);
		return query.getResultList();
	}

	@Override
	public List<BigInteger> getRoleByNo(Long wrkGrpNo) {
		Query query = entityManager.createNativeQuery("select role_id from role where number="+wrkGrpNo+" ");
		return query.getResultList();
	}

	@Override
	public List<Role> findRoleByNameNo(String name, Long number) {
		// TODO Auto-generated method stub
		Query query = entityManager.createNativeQuery("select * from role where name='"+name+"' and  number="+number+" ");
		return query.getResultList();
	}

}
