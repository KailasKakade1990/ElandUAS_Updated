package com.eland.uas.reqresp;

public class SystemOtpRequest {

	private String[] systemId;
	private String ipAddress;
	private String description;
	public String[] getSystemId() {
		return systemId;
	}
	public void setSystemId(String[] systemId) {
		this.systemId = systemId;
	}
	public String getIpAddress() {
		return ipAddress;
	}
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
}
