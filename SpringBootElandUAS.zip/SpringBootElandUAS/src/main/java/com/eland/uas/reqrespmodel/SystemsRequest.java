package com.eland.uas.reqrespmodel;

public class SystemsRequest {
	
	private Long systemId;
	private String name;
	private String description;
	private Long isUse;
	private Long inOtpUse;
	private String clientId;
	private String clientSecret;
	
	public Long getSystemId() {
		return systemId;
	}
	public void setSystemId(Long systemId) {
		this.systemId = systemId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Long getIsUse() {
		return isUse;
	}
	public void setIsUse(Long isUse) {
		this.isUse = isUse;
	}
	public Long getInOtpUse() {
		return inOtpUse;
	}
	public void setInOtpUse(Long inOtpUse) {
		this.inOtpUse = inOtpUse;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getClientSecret() {
		return clientSecret;
	}
	public void setClientSecret(String clientSecret) {
		this.clientSecret = clientSecret;
	}
}
