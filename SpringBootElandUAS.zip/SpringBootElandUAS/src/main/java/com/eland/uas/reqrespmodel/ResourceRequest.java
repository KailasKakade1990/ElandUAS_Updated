package com.eland.uas.reqrespmodel;

public class ResourceRequest {

	private String systemResourceId;
	private String systemId;
	private String resourcePath;
	private String resourceDesc;
	private boolean useYn;
	
	public String getSystemResourceId() {
		return systemResourceId;
	}
	public void setSystemResourceId(String systemResourceId) {
		this.systemResourceId = systemResourceId;
	}
	public String getSystemId() {
		return systemId;
	}
	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}
	public String getResourcePath() {
		return resourcePath;
	}
	public void setResourcePath(String resourcePath) {
		this.resourcePath = resourcePath;
	}
	public String getResourceDesc() {
		return resourceDesc;
	}
	public void setResourceDesc(String resourceDesc) {
		this.resourceDesc = resourceDesc;
	}
	public boolean isUseYn() {
		return useYn;
	}
	public void setUseYn(boolean useYn) {
		this.useYn = useYn;
	}
	
}
