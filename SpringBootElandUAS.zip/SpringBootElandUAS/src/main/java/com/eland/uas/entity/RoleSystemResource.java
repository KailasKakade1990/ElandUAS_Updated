package com.eland.uas.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "role_system_resource")
public class RoleSystemResource implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6866166570802973783L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "role_system_resource_id")
	private Long roleSystemResource_id;
	
	@ManyToOne
	@JoinColumn(name = "system_resource_id")
	private SystemsResource systemResource;
	
	@ManyToOne
	@JoinColumn(name = "system_role_id")
	private SystemsRole systemRole;
	
	@Column(name = "is_use",columnDefinition = "BIGINT(20) default 1")
	private Long isUse;

	public Long getRoleSystemResource_id() {
		return roleSystemResource_id;
	}

	public void setRoleSystemResource_id(Long roleSystemResource_id) {
		this.roleSystemResource_id = roleSystemResource_id;
	}

	public SystemsResource getSystemResource() {
		return systemResource;
	}

	public void setSystemResource(SystemsResource systemResource) {
		this.systemResource = systemResource;
	}

	public SystemsRole getSystemRole() {
		return systemRole;
	}

	public void setSystemRole(SystemsRole systemRole) {
		this.systemRole = systemRole;
	}

	public Long getIsUse() {
		return isUse;
	}

	public void setIsUse(Long isUse) {
		this.isUse = isUse;
	}
	
	
}
