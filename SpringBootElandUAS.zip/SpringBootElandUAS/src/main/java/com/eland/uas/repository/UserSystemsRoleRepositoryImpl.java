package com.eland.uas.repository;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.jpa.TypedParameterValue;
import org.hibernate.type.IntegerType;
import org.hibernate.type.LongType;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.eland.uas.entity.Resource;
import com.eland.uas.entity.Role;
import com.eland.uas.entity.SystemsResource;
import com.eland.uas.entity.User;
import com.eland.uas.entity.UserSystemsRole;

@Repository
@Transactional(readOnly = true)
public class UserSystemsRoleRepositoryImpl implements CustomUserSystemRoleRepository{

	@PersistenceContext
	EntityManager entityManager;
	 
	@Override
	public List<Role> getRoleBySystemId(Long systemId) {
		// TODO Auto-generated method stub
		Query query = entityManager.createNativeQuery("select u.role_id, u.name from role u inner join user_system_role usr on(u.role_id=usr.role_id) where usr.system_id="+systemId+" GROUP BY usr.role_id ", UserSystemsRole.class);
		//query.getResultList();
		  return query.getResultList();
	}

	@Override
	public List<User> getUserBySystemId(Long[] systemRoleIds) {
		// TODO Auto-generated method stub

		List<Long> ids = Arrays.asList(systemRoleIds);
		Query query = entityManager.createNativeQuery("select * from user u inner join user_system_role usr on(u.user_id=usr.user_id) where usr.system_role_id in (:system_role_ids)", User.class);
		query.setParameter("system_role_ids", ids);
		query.getResultList();
		  return query.getResultList();
	}

	@Override
	public List<BigInteger> getSystemIdByUserId(Long userId) {
		// TODO Auto-generated method stub
		Query query = entityManager.createNativeQuery("select s.system_id from system s inner join system_role sr on(s.system_id=sr.system_id) inner join user_system_role usr on(sr.system_role_id=usr.system_role_id) where usr.user_id="+userId+" ");
		//query.getResultList();
		  return query.getResultList();
	}

	@Override
	public List<User> getUserBySystemRoleId(Long systemRoleId) {
		Query query = entityManager.createNativeQuery("select * from user u inner join user_system_role usr on(u.user_id=usr.user_id) where usr.system_role_id="+systemRoleId+"", User.class);
		//query.getResultList();
		  return query.getResultList();
	}

}
