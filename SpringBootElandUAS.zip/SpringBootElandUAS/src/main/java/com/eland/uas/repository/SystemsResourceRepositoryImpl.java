package com.eland.uas.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.eland.uas.entity.Resource;
import com.eland.uas.entity.Role;
import com.eland.uas.entity.SystemsResource;

@Repository
@Transactional(readOnly = true)
public class SystemsResourceRepositoryImpl implements CustomSystemsResourceRepository{

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public List<Role> getResourceBySystemId(Long systemId) {
		Query query = entityManager.createNativeQuery("select r.resource_id, r.path from resource e inner join system_resource sr on(r.resource_id=sr.resource_id) where sr.system_id="+systemId+" GROUP BY sr.resource_id ", SystemsResource.class);
		//query.getResultList();
		  return query.getResultList();
	}


}
