package com.eland.uas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eland.uas.entity.Role;

public interface RoleRepository extends JpaRepository<Role, Long>, CustomRoleRepository {
	
}
