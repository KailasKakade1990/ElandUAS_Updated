package com.eland.uas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "otp")
public class Otp {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "otp_id")
	private Long otpId;

	@Column(name = "otp")
	private String otp;

	@ManyToOne()
	@JoinColumn(name = "systemotp_id", nullable = true)
	private SystemOtp systemOtp;

	@ManyToOne()
	@JoinColumn(name = "userId", nullable = true)
	private User user;

	public Long getOtpId() {
		return otpId;
	}

	public void setOtpId(Long otpId) {
		this.otpId = otpId;
	}

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public SystemOtp getSystemOtp() {
		return systemOtp;
	}

	public void setSystemOtp(SystemOtp systemOtp) {
		this.systemOtp = systemOtp;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}
